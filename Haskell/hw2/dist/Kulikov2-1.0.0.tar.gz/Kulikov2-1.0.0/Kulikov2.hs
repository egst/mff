{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE TypeFamilies      #-}

--import Slepys (wrongExamples, exampleRaw)

import Tools
import SlepysLexer  (lexSlepys)
import SlepysParser (parseSlepysTags)
import PrettySlepys
import Slepys

import Control.Monad (void)
import Data.Maybe
import Control.Monad.Trans.State
import System.Exit           (exitWith)
import System.Environment    (getArgs)
import Text.Megaparsec.Error (errorBundlePretty)

main = do
    args <- getArgs
    let file = head args
    raw <- readFile file
    case parseSlepys file raw of
        Right (Right slepys) -> case checkVars slepys of
            Just error       -> putStrLn (ppshow error)
            Nothing          -> putStrLn $ ppshow slepys
        Right (Left error)   -> putStr "Parser error at " >> putStrLn (errorBundlePretty error)
        Left  error          -> putStr "Lexer error at "  >> putStrLn (errorBundlePretty error)

parseSlepys file raw = parseSlepysTags file <$> lexSlepys file raw

--type SlepysState = StateT [[String]] Maybe
type SlepysState t = State StateVars (Maybe t)

data StateVars =
    StateVars {
        vars :: [[String]],
        defs :: [String]
    }

onVars f st = st { vars = f $ vars st }
onDefs f st = st { defs = f $ defs st }

findJust :: [SlepysState t] -> SlepysState t
findJust (first : rest) = do
    first' <- first
    if isJust first'
        then first
        else findJust rest
findJust [] = return Nothing

checkVars :: Slepys -> Maybe Occurance
checkVars (Slepys stmts) = evalState (checkVars'' stmts) StateVars { vars = [[]], defs = [] }

checkVars'' :: [Stmt] -> SlepysState Occurance
checkVars'' = findJust . foldr ((:) . checkVars') []

checkVars' :: Stmt -> SlepysState Occurance
checkVars' stmt @ (Simple s) =
    do  st <- get
        (Occurance (head' $ defs st) (Stmt s) <$>) <$> check s
checkVars' def @ Def {} =
    modify (onVars (defParams def :)) *>
    modify (onDefs (defName def :))   *>
    checkVars'' (defBody def)         <*
    modify (onVars tail')             <*
    modify (onDefs tail')
checkVars' cond @ Cond { ifElse = Just body2 } =
    findJust [
        do  st <- get
            (Occurance (head' $ defs st) (IfCond (ifCond cond)) <$>) <$> check (ifCond cond),
        checkVars'' (ifThen cond),
        checkVars'' body2
    ]
checkVars' cond @ Cond { ifElse = Nothing } =
    findJust [
        do  st <- get
            (Occurance (head' $ defs st) (IfCond (ifCond cond)) <$>) <$> check (ifCond cond),
        checkVars'' (ifThen cond)
    ]
checkVars' while @ While {} =
    findJust [
        do  st <- get
            (Occurance (head' $ defs st) (WhileCond (whileCond while)) <$>) <$> check (whileCond while),
        checkVars'' (whileBody while)
    ]

class Contextual t where
    check :: t -> SlepysState String

instance Contextual Simple where
    check s @ (Expr e)          = check e
    check s @ (Assign name val) = check val <* modify (onVars (onHead (name :)))

instance Contextual Expr3 where
    check (Bin3 _ x y) = findJust [check x, check y]
    check (E2 e)       = check e

instance Contextual Expr2 where
    check (Bin2 _ x y) = findJust [check x, check y]
    check (E1 e)       = check e

instance Contextual Expr1 where
    check (Bin1 _ x y) = findJust [check x, check y]
    check (E0 e)       = check e

instance Contextual Expr0 where
    check call @ Call {} = findJust [check (callFunc call), check (callArgs call)]
    check (E0' e)        = check e

instance Contextual Expr0' where
    check (Name   n) = check n
    check (Parens e) = check e
    check _          = return Nothing

instance Contextual [Expr3] where
    check = findJust . foldr ((:) . check) []

-- TODO: NonEmpty
instance Contextual String where
    check s = do
        st <- get
        return $ if s `elem` head (vars st)
            then Nothing
            else Just s
